#!/usr/bin/env python3
"""7B coder loop. Flag first. Propose only on miss. Never mint axioms.

Talks to OpenAI-compatible llama-server on OptiPlex:
  default http://127.0.0.1:8080/v1/chat/completions
Override:
  OPENROOT_LLM_URL
  OPENROOT_LLM_MODEL
"""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

import axiom_engine as ax

DEFAULT_URL = os.environ.get("OPENROOT_LLM_URL", "http://127.0.0.1:8080/v1/chat/completions")
DEFAULT_MODEL = os.environ.get("OPENROOT_LLM_MODEL", "qwen2.5-coder-7b-instruct")
PROMPT = Path(__file__).resolve().parent / "prompts" / "SYSTEM.txt"


def load_system() -> str:
    if PROMPT.exists():
        return PROMPT.read_text(encoding="utf-8")
    return (
        "You are the OpenRoot 7B coder. Return JSON only. "
        "Never invent axioms. On a known path return only {flag,hash}."
    )


def catalog_brief(limit: int = 40) -> str:
    rows = []
    for kind in ("axiom", "definition", "postulate", "theorem"):
        for rec in ax.load_jsonl(kind):
            rows.append(f"{rec['flag']} {rec['id']} {rec['statement'][:120]}")
            if len(rows) >= limit:
                return "\n".join(rows)
    return "\n".join(rows)


def chat(messages: list[dict], temperature: float = 0.1) -> str:
    body = json.dumps(
        {
            "model": DEFAULT_MODEL,
            "temperature": temperature,
            "max_tokens": 800,
            "messages": messages,
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        DEFAULT_URL,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        return json.dumps({"error": "llm_unreachable", "detail": str(e), "url": DEFAULT_URL})
    try:
        return data["choices"][0]["message"]["content"]
    except Exception:
        return json.dumps({"error": "bad_llm_shape", "raw": data})


def extract_json(text: str) -> dict:
    text = (text or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end < 0:
        return {"error": "no_json", "raw": text[:500]}
    try:
        return json.loads(text[start : end + 1])
    except json.JSONDecodeError as e:
        return {"error": "json_decode", "detail": str(e), "raw": text[:500]}


def run_query(query: str, use_llm: bool = True) -> dict:
    ax.seed_all(False)
    hit = ax.ask(query)
    if hit.get("hit") and hit.get("flag"):
        return {
            "hit": True,
            "recomputed": False,
            "flag": hit["flag"],
            "hash": hit.get("hash"),
            "id": hit.get("id"),
            "kind": hit.get("kind"),
            "statement": hit.get("statement"),
        }
    if not use_llm:
        return {
            "hit": False,
            "recomputed": False,
            "flag": None,
            "advice": "no flag. start llama-server then coder_loop.py ask --llm",
            "near": hit,
        }
    sys_prompt = load_system() + "\n\nKNOWN FLAGS\n" + catalog_brief()
    raw = chat(
        [
            {"role": "system", "content": sys_prompt},
            {
                "role": "user",
                "content": (
                    "Query: "
                    + query
                    + "\nIf this is already a known flag, return only "
                    + '{"flag":"...","hash":"..."}.\n'
                    + "Else propose ONE proof spec: "
                    + '{"id","statement","premises","conclude","proof":[{"rule","from","conclude"}]}.\n'
                    + "HARD rules only if you want a theorem: assume, eval_c, eval_s, eq_refl, need_gate.\n"
                    + "Do not invent axiom ids."
                ),
            },
        ]
    )
    spec = extract_json(raw)
    if spec.get("flag") and not spec.get("proof"):
        again = ax.lookup(spec["flag"])
        if again.get("hit"):
            rec = again["record"]
            return {"hit": True, "recomputed": False, "flag": rec.get("flag"), "hash": rec.get("hash"), "id": rec.get("id")}
        return {"hit": False, "flag": spec.get("flag"), "reason": "llm_flag_not_in_store"}
    if spec.get("error"):
        return {"hit": False, "valid": False, "reason": spec}
    if "statement" not in spec:
        return {"hit": False, "valid": False, "reason": "llm_missing_statement", "raw": spec}
    return ax.prove_and_flag(spec)


USAGE = "coder_loop.py ask <query> [--llm|--no-llm]\ncoder_loop.py catalog\n"


def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        sys.stdout.write(USAGE)
        return 0
    if argv[1] == "catalog":
        sys.stdout.write(catalog_brief(200) + "\n")
        return 0
    if argv[1] == "ask":
        args = argv[2:]
        use_llm = "--no-llm" not in args
        if "--llm" in args:
            use_llm = True
        q = " ".join(a for a in args if a not in ("--llm", "--no-llm"))
        print(ax.dumps(run_query(q, use_llm=use_llm)))
        return 0
    sys.stderr.write(USAGE)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
