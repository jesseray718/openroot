#!/usr/bin/env python3
"""FTS5 first. Optional vector RRF. One Ollama endpoint. No corpus re-embed."""
from __future__ import annotations

import argparse
import json
import math
import sqlite3
import struct
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from paths import pane, roots  # noqa: E402

OLLAMA = "http://127.0.0.1:11434/api/embeddings"
MODEL = "nomic-embed-text"
RRF_K = 60
VEC_DIM = 768
VEC_BYTES = VEC_DIM * 4


def embed_query(text: str) -> list[float] | None:
    payload = json.dumps({"model": MODEL, "prompt": f"search_query: {text}"}).encode()
    req = urllib.request.Request(OLLAMA, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode())
        return data.get("embedding")
    except Exception as e:
        print(f"embed_skip {e}", file=sys.stderr)
        return None


def cosine(a: list[float], blob: bytes) -> float:
    n = min(len(a), len(blob) // 4)
    if n <= 0:
        return -1.0
    b = struct.unpack(f"<{n}f", blob[: n * 4])
    dot = na = nb = 0.0
    for x, y in zip(a, b):
        dot += x * y
        na += x * x
        nb += y * y
    if na <= 0 or nb <= 0:
        return -1.0
    return dot / math.sqrt(na * nb)


def fts_search(con: sqlite3.Connection, query: str, k: int) -> list[dict]:
    # MATCH string: quote tokens that would break FTS syntax
    tokens = [t for t in query.replace('"', " ").replace("'", " ").split() if t]
    if not tokens:
        return []
    and_q = " ".join(tokens)
    or_q = " OR ".join(tokens)
    sql = """
    SELECT c.id, c.file_path, c.chunk_index, c.chunk_text,
           bm25(chunks_fts) AS rank
    FROM chunks_fts
    JOIN file_chunks c ON c.id = chunks_fts.rowid
    WHERE chunks_fts MATCH ?
    ORDER BY rank
    LIMIT ?
    """
    try:
        rows = con.execute(sql, (and_q, k)).fetchall()
        if len(rows) < 3:
            rows = con.execute(sql, (or_q, k)).fetchall()
    except sqlite3.DatabaseError as e:
        print(f"fts_error {e}", file=sys.stderr)
        return []
    out = []
    for i, (cid, path, idx, text, rank) in enumerate(rows, start=1):
        out.append(
            {
                "id": cid,
                "path": path,
                "chunk": idx,
                "text": text,
                "bm25": float(rank) if rank is not None else 99.0,
                "fts_rank": i,
            }
        )
    return out


def vector_search(
    con: sqlite3.Connection, qvec: list[float], candidate_ids: list[int], scan_cap: int
) -> list[tuple[int, float]]:
    hits: list[tuple[int, float]] = []
    if candidate_ids:
        qmarks = ",".join("?" * len(candidate_ids))
        rows = con.execute(
            f"SELECT chunk_id, embedding FROM file_chunk_embeddings WHERE chunk_id IN ({qmarks})",
            candidate_ids,
        ).fetchall()
    else:
        rows = con.execute(
            "SELECT chunk_id, embedding FROM file_chunk_embeddings LIMIT ?",
            (scan_cap,),
        ).fetchall()
    for cid, blob in rows:
        if not blob:
            continue
        hits.append((cid, cosine(qvec, blob)))
    hits.sort(key=lambda x: x[1], reverse=True)
    return hits[:scan_cap]


def rrf(fts_hits: list[dict], vec_hits: list[tuple[int, float]]) -> list[tuple[int, float]]:
    scores: dict[int, float] = {}
    for h in fts_hits:
        scores[h["id"]] = scores.get(h["id"], 0.0) + 1.0 / (RRF_K + h["fts_rank"])
    for rank, (cid, _sim) in enumerate(vec_hits, start=1):
        scores[cid] = scores.get(cid, 0.0) + 1.0 / (RRF_K + rank)
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("query", nargs="+")
    ap.add_argument("--mode", choices=("fts", "hybrid", "vector"), default="fts")
    ap.add_argument("--k", type=int, default=8)
    ap.add_argument("--db", default="")
    args = ap.parse_args()
    query = " ".join(args.query)
    r = roots()
    db = Path(args.db) if args.db else r["db"]
    if not db.is_file():
        print(f"FAIL no db {db}")
        print("run fts5_ensure.py --ingest first")
        return 2
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    fts = fts_search(con, query, max(args.k, 50) if args.mode == "hybrid" else args.k)
    print(f"pane={pane()} mode={args.mode} db={db} fts_hits={len(fts)}")

    if args.mode == "fts" or (args.mode == "hybrid" and len(fts) >= 5):
        use = fts[: args.k]
        if args.mode == "hybrid" and len(fts) >= 5:
            print("hybrid_short_circuit fts>=5 (η keep Ollama dark)")
        for h in use:
            snippet = " ".join((h["text"] or "").split())[:160]
            print(f"[fts r{h['fts_rank']} bm25={h['bm25']:.4f}] {h['path']}#{h['chunk']}")
            print(f"    {snippet}")
        con.close()
        return 0 if use else 1

    qvec = embed_query(query)
    if qvec is None:
        print("vector unavailable; dumping FTS only")
        for h in fts[: args.k]:
            snippet = " ".join((h["text"] or "").split())[:160]
            print(f"[fts r{h['fts_rank']} bm25={h['bm25']:.4f}] {h['path']}#{h['chunk']}")
            print(f"    {snippet}")
        con.close()
        return 0 if fts else 1

    cand = [h["id"] for h in fts]
    vec = vector_search(con, qvec, cand, scan_cap=256)
    if args.mode == "vector":
        by_id = {h["id"]: h for h in fts}
        for i, (cid, sim) in enumerate(vec[: args.k], start=1):
            row = by_id.get(cid) or con.execute(
                "SELECT file_path, chunk_index, chunk_text FROM file_chunks WHERE id=?",
                (cid,),
            ).fetchone()
            if isinstance(row, dict):
                path, idx, text = row["path"], row["chunk"], row["text"]
            elif row:
                path, idx, text = row
            else:
                continue
            snippet = " ".join((text or "").split())[:160]
            print(f"[vec r{i} cos={sim:.4f}] {path}#{idx}")
            print(f"    {snippet}")
        con.close()
        return 0

    fused = rrf(fts, vec)
    lookup = {h["id"]: h for h in fts}
    for cid, score in fused[: args.k]:
        h = lookup.get(cid)
        if h is None:
            row = con.execute(
                "SELECT file_path, chunk_index, chunk_text FROM file_chunks WHERE id=?",
                (cid,),
            ).fetchone()
            if not row:
                continue
            path, idx, text = row
        else:
            path, idx, text = h["path"], h["chunk"], h["text"]
        snippet = " ".join((text or "").split())[:160]
        print(f"[rrf {score:.5f}] {path}#{idx}")
        print(f"    {snippet}")
    con.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
